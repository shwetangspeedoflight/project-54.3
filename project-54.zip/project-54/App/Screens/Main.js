import React, { Component } from 'react';

import { Text, View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Constants } from 'expo';
import { Metrics } from '../Themes';

// You can import from local files

export default class Main extends Component {
  
  state = {
    profiles: [
      {key: "Ab", name: "Abdallah", age: 20, pros: "He/Him", loc: "Stanford", major: "CS"},
      {key: "Sn", name: "Santiago", age: 22, pros: "He/Him", loc: "Stanford", major: "CS"},
      {key: "Cr", name: "Crystal", age: 20, pros: "She/Her", loc: "Stanford", major: "MS & E"}
    ]
  }
  
  static navigationOptions = ({navigation}) => {
    return {
      headerTitle: "Main Screen"
    }
  }
  
  toNextPage = (item) => {
    this.props.navigation.navigate('DetailedScreen', item);
  }
  
  _renderItem = (item) => {
    return (
      <TouchableOpacity style={styles.item} onPress={() => this.toNextPage(item)}>
        <Text> {item.name} </Text>
      </TouchableOpacity>
    )
  }
  
  render() {
    return (
        <View style={styles.container}>
          <FlatList
            style={styles.list}
            data={this.state.profiles}
            renderItem = {({item}) => this._renderItem(item)}
            ItemSeparatorComponent={()=> <View style={styles.separator}/>}
          />
        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
  },
  list: {
    flex: 1,
  },
  item: {
    backgroundColor: 'white',
    alignItems: 'center',
    paddingTop: Metrics.marginVertical*2,
    paddingBottom: Metrics.marginVertical*2
  },
  separator: {
    height: Metrics.marginVertical*2
  }
});
