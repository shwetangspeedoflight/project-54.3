import React, { Component } from 'react';

import { Text, View, StyleSheet } from 'react-native';
import { Constants } from 'expo';
import { Metrics } from '../Themes';

// You can import from local files

export default class Detailed extends Component {
  state = {
    name: '',
    age: -1,
    pros: '',
    loc: '',
    major: '',
  };

  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state;
    return {
      headerTitle: params.name,
    };
  };

  componentDidMount() {
    this.setState(this.props.navigation.state.params);
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.card}>

          <View style={styles.pictureView}>
            <View style={styles.picture} />

            <View style={styles.pictureDetails}>
              <Text style={{ fontWeight: 'bold' }}>{this.state.name}</Text>
            </View>
          </View>

          <View style={styles.jediRowItem}>
            <Text style={{ fontWeight: 'bold' }}>Age</Text>
            <Text style={{ fontWeight: 'bold' }}>Pronouns</Text>
          </View>
          <View style={[styles.jediRowItem, { marginTop: 0 }]}>
            <Text>{this.state.age}</Text>
            <Text>{this.state.pros}</Text>
          </View>

          <View style={styles.jediRowItem}>
            <Text style={{ fontWeight: 'bold' }}>Major</Text>
            <Text style={{ fontWeight: 'bold' }}>Location</Text>
          </View>
          <View style={[styles.jediRowItem, { marginTop: 0 }]}>
            <Text>{this.state.major}</Text>
            <Text>{this.state.loc}</Text>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    padding: Metrics.doubleBaseMargin,
    width: Metrics.screenWidth * 0.9,
    borderWidth: Metrics.borderWidth,
    borderRadius: Metrics.buttonRadius,
  },
  pictureView: {
    marginLeft: Metrics.marginHorizontal,
    marginRight: Metrics.marginHorizontal,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  picture: {
    height: Metrics.images.large,
    width: Metrics.images.large,
    borderRadius: Metrics.images.large * 0.5,
  },
  pictureDetails: {
    flexDirection: 'column',
    marginLeft: Metrics.marginHorizontal,
    marginRight: Metrics.marginHorizontal,
  },
  jediRowItem: {
    marginTop: Metrics.marginVertical,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
});
