// leave off @2x/@3x
const images = {
  logo: require('../Images/nyt.png'),
  main: require('../Images/mainScreenshot.png'),
  article: require('../Images/article.png')
}

export default images
