import {StackNavigator} from 'react-navigation'; // 1.0.1

import MainScreen from '../Screens/Main';
import DetailedScreen from '../Screens/Detailed';

const Navigator = StackNavigator({
  MainScreen : {screen: MainScreen},
  DetailedScreen : {screen: DetailedScreen}
},
{
  
});

export default Navigator;