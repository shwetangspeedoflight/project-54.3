import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';


class RedButton extends Component {
  render(){
    return(
      <Button color="red" title="Sound 1"/>
    )
  }
}


export default class App extends Component {
  render() {
    return (
      <View style={{marginTop: 100}}>
        <RedButton/>
        < LimeButton />
        < BlueButton/>
        <YellowButton/>
      </View>
    );
  }
}

class LimeButton extends Component {
  render() {
    return(
        <View style={{marginTop: 50}}>
      <Button color = "lime" title = "Sound 2"/>

        </View>
    )
  }
}

class BlueButton extends Component {
   render() {
     return(
        <View style={{marginTop: 60}}>
      <Button color = "blue" title = "Sound 3"/>
      </View>

     )
   }
}

class YellowButton extends Component {
   render() {
     return(
        <View style={{marginTop: 70}}>
      <Button color = "yellow" title = "Sound 4"/>
      </View>
     )
   }
}

